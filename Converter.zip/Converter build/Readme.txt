If the computer you're using doesn't have .NET Framework 3.5 you may need to install it.
The following link has the full download if the computer doesn't have internet or you don't want to connect it,
you can transfer the installer to it via usb drive:

https://www.microsoft.com/en-us/download/details.aspx?id=25150

*** use at your own risk - no guarantees about function or safety ***


*** Notes ***
The program extracts all of the X and Y values to reformat them to your modified 3rd example, minus the first and last occurrences
which I assumed were not needed based on the 3rd file.
It adds all of what I'm assuming are comments (;***) from your modified file such as: 
;R73=1    ;M49 RETRACT
;R74=1    ;M49 ZDRILL
;R75=1    ;M49 POWER SETTING

There is about a 32k character limit in its current form, the sample output is about 750 characters.
You can add as many steps you want within that limit.

Only the paste, copy and [>] (convert) buttons work right now.

Example File 1
% 
G00 G20 G40 G49 G80 G90 G17 
G28 G91 Z0 
T337 
G54 G90 
G00 **X-2.787** **Y2.0252** S2412 M03 **not converted**
G43 Z1. H337 M08 
G98 G84 X-2.787 Y2.0252 Z-0.5 R0.1 F100.5 H0 
Y1.6508 
X-2.3675 Y1.838 
Y1.4635 
X-2.787 Y1.2763 
Y0.9018 
X-2.3675 Y1.089 
Y0.7145 
G80 
G28 G91 Z0 M09 
G28 G91 **X0** **Y0** M05 **not converted**
T0 
M02 
% 

Without my **comments** converts to this output:

WPS(60,33,35,12,0.40,750) ;1MM SETTINGS
SERVO(575,216,220,100,100)
G0G54G90
R70=0.025 ;M50 RETRACT
R71=-3.75 ;M50 ZDRILL
R72=60    ;M50 POWER SETTING
;R73=1    ;M49 RETRACT
;R74=1    ;M49 ZDRILL
;R75=1    ;M49 POWER SETTING
/M140
/M141
/M142
/M143
X0Y0
W0
X-2.787 Y2.0252  ;1
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
Y1.6508  ;2
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
X-2.3675 Y1.838  ;3
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
Y1.4635  ;4
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
X-2.787 Y1.2763  ;5
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
Y0.9018  ;6
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
X-2.3675 Y1.089  ;7
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
Y0.7145  ;8
M01
/M70
/M142
/M50(R70,R71,R72)
;/M49(R73,R74,R75)
M30

